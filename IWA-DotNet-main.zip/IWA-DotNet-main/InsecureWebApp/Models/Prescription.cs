﻿namespace MicroFocus.InsecureWebApp.Models
{
    public class Prescription
    {
        public int ID { get; set; }
        public string DocName { get; set; }
        public string Advice { get; set; }
        public string Product { get; set; }
        public string UserId { get; set; }
    }
}
