﻿using Microsoft.AspNetCore.Identity;

namespace MicroFocus.InsecureWebApp.Models
{
    public class User : ApplicationUser
    {
    }
}