﻿namespace MicroFocus.InsecureWebApp.Models
{
    public class FileModel
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public string DirectoryName { get; set; }
    }
}
