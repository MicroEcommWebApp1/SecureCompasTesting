﻿namespace MicroFocus.InsecureWebApp.Models
{
    public class PrescriptionFileModel
    {
        public string FileName { get; set; }

        public string FileDesc { get; set; }

        public string xml { get; set; }
    }
}
