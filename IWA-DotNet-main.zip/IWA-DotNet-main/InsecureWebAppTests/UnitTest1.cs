using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InsecureWebAppTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }

        [TestMethod]
        public void TestMethod2()
        {
        }
    }
}
